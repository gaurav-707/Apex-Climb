# 🏎️ Los Santos Exotics & Off-Road VI

[![Live Demo](https://img.shields.io/badge/Play_Live-GitHub_Pages-10b981?style=for-the-badge)](https://gaurav-707.github.io/los-santos-exotics-vi/)

A self-contained 2.5D/3D Supercar & Off-Road Physics Racing Game built by **[@gaurav-707](https://github.com/gaurav-707)** using **Three.js (r128)**, **Matter.js (0.19.0)**, and a real-time **Web Audio API** race-car engine & sample synthesizer.

- **Live Game URL**: [https://gaurav-707.github.io/los-santos-exotics-vi/](https://gaurav-707.github.io/los-santos-exotics-vi/)
- **Repository**: [https://github.com/gaurav-707/los-santos-exotics-vi](https://github.com/gaurav-707/los-santos-exotics-vi)
